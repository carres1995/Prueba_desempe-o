Herramienta para hacer gestion de registro y ventas de inventario, con un reporte final sobre datos.

# id: 
se auto incrementa en los dos registros llamando funcion general.

### SISTEMA DE INVENTARIOS Y VENTAS ####
tiene 3 menus 
    menu de inicio
    
        inventario
        ventas
        reportes
        salir
            menu inventarios
                registrar inventario
                consultar resgistro
                mostrar registros
                actualizar inventario
                eliminar inventario
                salir
            menu ventas  
                registro ventas
                mostrar ventas
                consultar ventas
                salir
            menu reportes
                reporte ingreso netos y brutos
                reporte agrupando libros mostrando 3 mas vendidos
                reporte ventas agrupadas
                salir

## LOGICA GESTION INVENTARIO
    se crea inventario de producto nuevo y todas las funcionalidades basicas del crud, registrar, buscar, mostrar, actualizar y eliminar inventarios de libros.

## LOGICA VENTAS
    aca esta el corazon del proyecto donde se crean solicitudes, se generan condicionales de entrada de cantidades, y se modifica su valor, de acuerdo a la venta se muestran los registros y se consultan igualmente por id.

## LOGICA REPORTE
    se generaron las operaciones donde se muestra el reporte de ventas mostrando el top 3 mas vendidas, agrupando libros y mostrando sus cantidades sumadas, y el de valor bruto y valor neto.

aca cierra el programa.    





    


